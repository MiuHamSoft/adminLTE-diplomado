package mx.edu.utp.demospring.student.usecase;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.database.StudentRepository;
import mx.edu.utp.demospring.student.domain.Student;
import mx.edu.utp.demospring.student.domain.StudentImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CreateStudentTest {

	private final StudentRepository repository = mock(StudentRepository.class);

	private UseCase<Student, String> createStudent;
	private Student student;

	@BeforeEach
	final void createCreateStudent() {
		createStudent = CreateStudent.create(repository);
		student = StudentImpl.builder()
				.id("id")
				.curp("sdfgsdafgsdgds")
				.firstName("Jorge")
				.lastName("Perez")
				.build();
	}

	@Test
	final void createStudentTest() {
		happyPath();

		final String expected = String.format(
				"Se inserto con exito el alumno con matricula %s",
				student.getId()
		);

		final String actual = createStudent.execute(student);
		assertThat(actual).isEqualTo(expected);
	}

	@Test
	final void curpAlreadyExistsTest() {
		happyPath();
		givenCurpAlreadyExists();

		final Throwable throwable = catchThrowable(() -> {
			createStudent.execute(student);
		});

		assertThat(throwable)
				.isInstanceOf(IllegalArgumentException.class)
				.hasMessageContainingAll("curp");
	}

	private void happyPath() {
		givenCurpDoesNotExists();
		givenDbInsertionIsSuccessful();
	}

	private void givenDbInsertionIsSuccessful() {
		when(repository.insertStudent(any(Student.class)))
				.thenReturn(true);
	}

	private void givenCurpDoesNotExists() {
		when(repository.curpExists(anyString()))
				.thenReturn(false);
	}

	private void givenCurpAlreadyExists() {
		when(repository.curpExists(anyString()))
				.thenReturn(true);
	}
}