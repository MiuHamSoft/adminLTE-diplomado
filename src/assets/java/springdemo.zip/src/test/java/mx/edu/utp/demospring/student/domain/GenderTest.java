package mx.edu.utp.demospring.student.domain;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class GenderTest {

	@Test
	final void sumTestWithJunit() {
		final int expected = 5;
		final int actual = 2 + 3;
		assertEquals(expected,actual);
	}

	@Test
	final void sumTestWithAssertJ() {
		final int expected = 5;
		final int actual = 2 + 3;
		assertThat(actual).isEqualTo(expected);
	}

	@Test
	final void getNameTest() {
		final Gender gender = Gender.MALE;
		final String expected = "Hombre";
		final String actual = gender.getName();
		assertThat(actual).isEqualTo(expected);
	}

	@Test
	final void getAbbreviationTest() {
		final Gender gender = Gender.MALE;
		final char expected = 'H';
		final char actual = gender.getAbbreviation();
		assertThat(actual).isEqualTo(expected);
	}

	@Test
	final void getValueOfTest() {
		final String value = "hombre";
		final Gender expected = Gender.MALE;
		final Gender actual = Gender.getValueOf(value);
		assertThat(actual).isEqualTo(expected);
	}

	@Test
	final void toStringTest() {
		final Gender gender = Gender.MALE;
		final String expected = "HOMBRE";
		final String actual = gender.toString();
		assertThat(actual).isEqualTo(expected);
	}
}