package mx.edu.utp.demospring.student.domain;

public final class StudentImpl implements Student {

	private final String id;
	private final String curp;
	private final String firstName;
	private final String lastName;
	private final Group group;
	private final Gender gender;
	private final int yearOfBirth;

	public static final class Builder {

		private String id;
		private String curp;
		private String firstName;
		private String lastName;
		private Group group;
		private Gender gender;
		private int yearOfBirth;

		private Builder() {
		}

		public Builder from(final Student student) {
			id = student.getId();
			curp = student.getCurp();
			firstName = student.getFirstName();
			lastName = student.getLastName();
			group = student.getGroup();
			gender = student.getGender();
			yearOfBirth = student.getYearOfBirth();
			return this;
		}

		public Builder id(final String id) {
			this.id = id;
			return this;
		}

		public Builder curp(final String curp) {
			this.curp = curp;
			return this;
		}

		public Builder firstName(final String firstName) {
			this.firstName = firstName;
			return this;
		}

		public Builder lastName(final String lastName) {
			this.lastName = lastName;
			return this;
		}

		public Builder group(final Group group) {
			this.group = group;
			return this;
		}

		public Builder gender(final Gender gender) {
			this.gender = gender;
			return this;
		}

		public Builder yearOfBirth(final int yearOfBirth) {
			this.yearOfBirth = yearOfBirth;
			return this;
		}

		public Student build() {
			final Student student = new StudentImpl(this);
			final StudentValidator validator = StudentValidator.create(student);
			return validator.validate();
		}
	}

	public static Builder builder() {
		return new Builder();
	}

	private StudentImpl(final Builder builder) {
		id = builder.id;
		curp = builder.curp;
		firstName = builder.firstName;
		lastName = builder.lastName;
		group = builder.group;
		gender = builder.gender;
		yearOfBirth = builder.yearOfBirth;
	}

	public String getId() {
		return id;
	}

	public String getCurp() {
		return curp;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public Group getGroup() {
		return group;
	}

	public Gender getGender() {
		return gender;
	}

	public int getYearOfBirth() {
		return yearOfBirth;
	}

	@Override
	public String getGenderAsString() {
		return String.valueOf(gender.getAbbreviation());
	}

	@Override
	public int getIdGroup() {
		return group.getId();
	}
}