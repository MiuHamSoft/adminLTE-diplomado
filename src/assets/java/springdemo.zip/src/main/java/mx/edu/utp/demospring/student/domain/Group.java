package mx.edu.utp.demospring.student.domain;

public interface Group {
	int getSemester();
	char getLetter();
	int getId();
}