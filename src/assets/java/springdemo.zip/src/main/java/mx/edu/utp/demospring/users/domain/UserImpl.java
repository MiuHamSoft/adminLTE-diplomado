package mx.edu.utp.demospring.users.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.gson.Gson;

@JsonDeserialize(builder = UserImpl.Builder.class)
public final class UserImpl implements User{

	private final int id;
	private final String username;
	private final String firstName;
	private final String fathersLastName;
	private final String mothersLastName;
	private final String fullName;
	private final String password;
	private final int idRole;
	private final String role;
	private final String token;

	@SuppressWarnings("PublicConstructor")
	@JsonPOJOBuilder(withPrefix = "")
	public static final class Builder {

		private int id;
		private String username;
		private String firstName;
		private String fathersLastName;
		private String mothersLastName;
		private String password;
		private int idRole;
		private String role;
		private String token;

		public Builder id(final int id) {
			this.id = id;
			return this;
		}

		public Builder username(final String username) {
			this.username = username;
			return this;
		}

		public Builder firstName(final String firstName) {
			this.firstName = firstName;
			return this;
		}

		public Builder fathersLastName(final String fathersLastName) {
			this.fathersLastName = fathersLastName;
			return this;
		}

		public Builder mothersLastName(final String mothersLastName) {
			this.mothersLastName = mothersLastName;
			return this;
		}

		public Builder password(final String password) {
			this.password = password;
			return this;
		}

		public Builder idRole(final int idRole) {
			this.idRole = idRole;
			return this;
		}

		public Builder role(final String role) {
			this.role = role;
			return this;
		}

		public Builder token(final String token) {
			this.token = token;
			return this;
		}

		public Builder from(final User user){
			id = user.getId();
			username = user.getUsername();
			firstName = user.getFirstName();
			fathersLastName = user.getFathersLastName();
			mothersLastName = user.getMothersLastName();
			password = user.getPassword();
			idRole = user.getIdRole();
			role = user.getRole();
			token = user.getToken();
			return this;
		}

		public User build() {
			return new UserImpl(this);
		}
	}

	private UserImpl(final Builder builder) {
		id = builder.id;
		username = builder.username;
		firstName = builder.firstName;
		fathersLastName = builder.fathersLastName;
		mothersLastName = builder.mothersLastName;
		fullName = String.format("%s %s %s", fathersLastName, mothersLastName, firstName);
		password = builder.password;
		idRole = builder.idRole;
		role = builder.role;
		token = builder.token;
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public String getFirstName() {
		return firstName;
	}

	@Override
	public String getFathersLastName() {
		return fathersLastName;
	}

	@Override
	public String getMothersLastName() {
		return mothersLastName;
	}

	@Override
	public String getFullName() {
		return fullName;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public int getIdRole() {
		return idRole;
	}

	@Override
	public String getRole() {
		return role;
	}

	@Override
	public String getToken() {
		return token;
	}

	@Override
	public String toString() {
		final Gson gson = new Gson();
		return gson.toJson(this);
	}
}