package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Student;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.Function;

final class GetStudentWithId implements Function<String,Student> {

	private final JdbcTemplate template;

	private GetStudentWithId(final JdbcTemplate template) {
		this.template = template;
	}

	static Function<String,Student> create(final JdbcTemplate template) {
		return new GetStudentWithId(template);
	}

	@Override
	public Student apply(final String idStudent) {
		return template.queryForObject(
				StudentMapper.QUERY,
				StudentMapper.create(),
				idStudent
		);
	}
}