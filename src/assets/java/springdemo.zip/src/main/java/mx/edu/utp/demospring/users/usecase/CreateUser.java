package mx.edu.utp.demospring.users.usecase;

import mx.edu.utp.demospring.api.RepositoryException;
import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.users.database.UsersRepository;
import mx.edu.utp.demospring.users.domain.User;

public final class CreateUser implements UseCase<User, String> {

	private final UsersRepository repository;
	private User user;

	public static UseCase<User, String> create(final UsersRepository repository) {
		return new CreateUser(repository);
	}

	private CreateUser(final UsersRepository repository) {
		this.repository = repository;
	}

	@Override
	public String execute(final User user) {
		setUser(user);
		verifyIfUsernameIsRepeated();
		insertUserInDb();
		return getSuccessMessage();
	}

	private void setUser(final User user) {
		this.user = user;
	}

	private void verifyIfUsernameIsRepeated() {
		final boolean exists = repository.userExistsWithUsername(getUsername());

		if (!exists) {
			throw new IllegalArgumentException(getRepeatedUsernameWarning());
		}
	}

	private String getRepeatedUsernameWarning() {
		return String.format(
				"El nombre de usuario %s ya se encuentra registrado",
				getUsername()
		);
	}

	private String getUsername() {
		return user.getUsername();
	}

	private void insertUserInDb() {
		final boolean success = repository.createUser(user);

		if (!success) {
			throw RepositoryException.create(getFailureWarning());
		}
	}

	private String getFailureWarning() {
		return String.format(
				"Hubo un problema al tratar de dar de alta al usuario %s",
				getFullName()
		);
	}

	private String getFullName() {
		return user.getFullName();
	}

	private String getSuccessMessage() {
		return String.format("Se inserto con exito el usuario %s", getFullName());
	}
}