package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Group;
import mx.edu.utp.demospring.student.domain.GroupImpl;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Map;
import java.util.function.IntFunction;

final class GetGroupWithId implements IntFunction<Group> {

	private static final String QUERY =
			"SELECT id, letter, semester FROM curso.groups where id = ?;";
	private final JdbcTemplate template;

	private GetGroupWithId(final JdbcTemplate template) {
		this.template = template;
	}

	static IntFunction<Group> create(final JdbcTemplate template) {
		return new GetGroupWithId(template);
	}

	@Override
	public Group apply(final int idGroup) {
		final Map<String, Object> row = template.queryForMap(QUERY, idGroup);

		final CharSequence letter = (CharSequence) row.get("letter");
		final int semester = (int) row.get("semester");

		return GroupImpl.builder()
				.id(idGroup)
				.letter(letter)
				.semester(semester)
				.build();
	}
}