package mx.edu.utp.demospring.student.controller;

import mx.edu.utp.demospring.api.JSend;
import mx.edu.utp.demospring.api.Success;
import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.adapter.PdfGenerator;
import mx.edu.utp.demospring.student.domain.Student;
import mx.edu.utp.demospring.utils.Mapper;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

import static org.slf4j.LoggerFactory.getLogger;

@RestController
@EnableScheduling
public class StudentController {

	private static final Logger LOGGER = getLogger(StudentController.class);
	private static final String PATH = "/api/v1/secure/students/";
	private static final String PATH_WITH_ID = "/api/v1/secure/students/{id}/";
	private static final String PDF = "/api/v1/secure/students/pdf/";
	private static final String PATH_WITH_CURP = "/api/v1/secure/students/curp/{curp}/";

	@Autowired
	private UseCase<String, Student> getStudentWithId;

	@Autowired
	private UseCase<Student, String> createStudent;

	@Autowired
	private UseCase<Student, String> updateStudent;

	@Autowired
	private Mapper<String, Student> studentMapper;

	@Autowired
	private UseCase<String, Student> getStudentWithCurp;

	@Autowired
	private UseCase<Void, List<Student>> getAllStudents;

	@Autowired
	private UseCase<String, String> deleteStudentWithId;

	@Autowired
	private PdfGenerator<List<Student>, String> pdfGenerator;

	@GetMapping(PATH)
	public final JSend<List<Student>> getAllStudents() {
		final List<Student> students = getAllStudents.execute(null);
		return Success.<List<Student>>builder()
				.data(students)
				.build();
	}

	@GetMapping(PATH_WITH_ID)
	public final JSend<Student> getStudentWithId(@PathVariable("id") final String id) {
		final Student student = getStudentWithId.execute(id);
		return Success.<Student>builder()
				.data(student)
				.build();
	}

	@PostMapping(PATH)
	public final JSend<Student> createStudent(final HttpEntity<String> entity) {
		final String json = entity.getBody();
		final Student student = studentMapper.from(json);
		final String result = createStudent.execute(student);
		LOGGER.info(result);

		return Success.<Student>builder()
				.message(result)
				.data(student)
				.build();
	}

	@PutMapping(PATH)
	public final JSend<Student> updateStudent(final HttpEntity<String> entity) {
		final String json = entity.getBody();
		final Student student = studentMapper.from(json);
		final String result = updateStudent.execute(student);
		LOGGER.info(result);

		return Success.<Student>builder()
				.message(result)
				.data(student)
				.build();
	}

	@GetMapping(PATH_WITH_CURP)
	public final JSend<Student> getStudentWithCurp(@PathVariable("curp") final String curp) {
		final Student student = getStudentWithCurp.execute(curp);
		return Success.<Student>builder()
				.data(student)
				.build();
	}

	@Scheduled(cron = "0 * * * * *")
	private static void cron() {
		final LocalDateTime now = LocalDateTime.now();
		LOGGER.info("{}", now);
	}

	@GetMapping(PDF)
	public final JSend<String> getPdfWithStudents() {
		final List<Student> students = getAllStudents.execute(null);
		final String pdfAsBase64 = pdfGenerator.generate(students);

		return Success.<String>builder()
				.data(pdfAsBase64)
				.build();
	}

	@DeleteMapping(PATH_WITH_ID)
	public final JSend<String> deleteStudentWithId(@PathVariable("id") final String id) {
		final String result = deleteStudentWithId.execute(id);
		return Success.<String>builder()
				.message(result)
				.build();
	}
}