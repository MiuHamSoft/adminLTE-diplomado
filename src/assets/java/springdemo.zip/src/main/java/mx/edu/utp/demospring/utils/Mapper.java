package mx.edu.utp.demospring.utils;

@FunctionalInterface
public interface Mapper <I,O>{
	O from(I param);
}