package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Gender;
import mx.edu.utp.demospring.student.domain.Group;
import mx.edu.utp.demospring.student.domain.GroupImpl;
import mx.edu.utp.demospring.student.domain.Student;
import mx.edu.utp.demospring.student.domain.StudentImpl;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public final class StudentMapper implements RowMapper<Student> {

	static final String QUERY =
			"SELECT id, serial, first_name, last_name, curp, gender, yearofbirth, id_group, letter, semester " +
			"FROM curso.students_groups_view where id = ?;";

	private StudentMapper() {
	}

	public static RowMapper<Student> create() {
		return new StudentMapper();
	}

	@Override
	public Student mapRow(final ResultSet rs, final int rowNum) throws SQLException {
		final String id = rs.getString("id");
		final String curp = rs.getString("curp");
		final String firstName = rs.getString("first_name");
		final String lastName = rs.getString("last_name");
		final String genderAsString = rs.getString("gender");
		final char genderAsChar = genderAsString.charAt(0);
		final Gender gender = Gender.getValueOf(genderAsChar);
		final int yearOfBirth = rs.getInt("yearOfBirth");

		final Group group = getGroup(rs);

		return StudentImpl.builder()
				.id(id)
				.curp(curp)
				.firstName(firstName)
				.lastName(lastName)
				.gender(gender)
				.yearOfBirth(yearOfBirth)
				.group(group)
				.build();
	}

	private static Group getGroup(final ResultSet rs) throws SQLException {
		final int idGroup = rs.getInt("id_group");
		final int semester = rs.getInt("semester");
		final String letter = rs.getString("letter");

		return GroupImpl.builder()
				.id(idGroup)
				.semester(semester)
				.letter(letter)
				.build();
	}
}