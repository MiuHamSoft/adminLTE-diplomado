package mx.edu.utp.demospring.student.domain;

import mx.edu.utp.demospring.utils.Validator;

public final class StudentValidator {

	private static final int MAX_LENGTH = 40;
	private static final int MIN_LENGTH = 3;

	private final Validator<Student> validator;

	public static StudentValidator create(final Student student) {
		return new StudentValidator(student);
	}

	private StudentValidator(final Student student) {
		validator = Validator.of(student);
	}

	Student validate() {
		validateFirstName();
		validateLastName();
		return validator.get();
	}

	private void validateFirstName() {
		validator
				.validate(p -> p.getFirstName().isBlank(), "El nombre no puede estar vacio")
				.validate(p -> p.getFirstName().length() > MAX_LENGTH, "El nombre no puede tener mas de 40 caractereres")
				.validate(p -> p.getFirstName().length() < MIN_LENGTH, "El nombre no puede tener menos de dos caracteres");
	}

	private void validateLastName() {
		validator
				.validate(p -> p.getLastName().isBlank(), "Los apellidos no pueden estar vacios")
				.validate(p -> p.getLastName().length() > MAX_LENGTH, "Los apellidos no pueden tener mas de 40 caractereres")
				.validate(p -> p.getLastName().length() < MIN_LENGTH, "Los apellidos no pueden tener menos de dos caracteres");
	}
}