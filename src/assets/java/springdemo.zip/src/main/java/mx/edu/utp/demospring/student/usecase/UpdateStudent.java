package mx.edu.utp.demospring.student.usecase;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.database.StudentRepository;
import mx.edu.utp.demospring.student.domain.Student;

public final class UpdateStudent implements UseCase<Student, String> {

	private final StudentRepository repository;
	private Student student;

	public static UseCase<Student, String> create(final StudentRepository repository) {
		return new UpdateStudent(repository);
	}

	private UpdateStudent(final StudentRepository repository) {
		this.repository = repository;
	}

	@Override
	public String execute(final Student student) {
		setStudent(student);
		verifyIfStudentExists();
		tryToUpdateStudentInDb();
		return getSuccessMessage();
	}

	public void setStudent(final Student student) {
		this.student = student;
	}

	private void verifyIfStudentExists() {
		final boolean exists = repository.studentExistsWithId(getIdStudent());

		if (!exists) {
			throw new IllegalArgumentException(getNonExistentStudentWarning(getIdStudent()));
		}
	}

	private String getIdStudent() {
		return student.getId();
	}

	private static String getNonExistentStudentWarning(final String idStudent) {
		return String.format("No existe el estudiante con matricula: %s", idStudent);
	}

	private void tryToUpdateStudentInDb() {
		final boolean success = repository.updateStudent(student);

		if (!success) {
			throw new RuntimeException(getFailureWarning());
		}
	}

	private String getFailureWarning() {
		return String.format(
				"Hubo un problema al intentar de actualizar al alumno con matricula: %s",
				getIdStudent()
		);
	}

	private String getSuccessMessage() {
		return String.format("Se actualizo con exito el estudiante con matricula: %s", getIdStudent());
	}
}