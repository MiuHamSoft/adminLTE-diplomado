package mx.edu.utp.demospring.student.usecase;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.database.StudentRepository;

public final class DeleteStudentWithId implements UseCase<String, String> {

	private final StudentRepository repository;
	private String idStudent;

	private DeleteStudentWithId(final StudentRepository repository) {
		this.repository = repository;
	}

	public static UseCase<String, String> create(final StudentRepository repository) {
		return new DeleteStudentWithId(repository);
	}

	@Override
	public String execute(final String idStudent) {
		setIdStudent(idStudent);
		verifyIfStudentExistsWithId();
		tryToDeleteStudentInDb();
		return getSuccessMessage();
	}

	private void setIdStudent(final String idStudent) {
		this.idStudent = idStudent;
	}

	private void verifyIfStudentExistsWithId() {
		final boolean exists = repository.studentExistsWithId(idStudent);

		if (!exists) {
			throw new IllegalArgumentException(getNonExistentStudentWarning(idStudent));
		}
	}

	private static String getNonExistentStudentWarning(final String idStudent) {
		return String.format("No existe el estudiante con matricula:%s", idStudent);
	}

	private void tryToDeleteStudentInDb() {
		final boolean success = repository.deleteStudentWithId(idStudent);

		if (!success) {
			throw new RuntimeException(getFailureMessage(idStudent));
		}
	}

	private static String getFailureMessage(final String idStudent) {
		return String.format("No fue posible eliminar al estudiante con matricula: %s", idStudent);
	}

	private String getSuccessMessage() {
		return String.format("Se elimino con exito el estudiante con matricula: %s", idStudent);
	}
}