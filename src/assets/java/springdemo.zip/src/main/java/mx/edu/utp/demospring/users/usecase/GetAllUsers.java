package mx.edu.utp.demospring.users.usecase;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.users.database.UsersRepository;
import mx.edu.utp.demospring.users.domain.User;

import java.util.Comparator;
import java.util.List;

public final class GetAllUsers implements UseCase<Void, List<User>> {

	private final UsersRepository repository;

	public static UseCase<Void, List<User>> create(final UsersRepository repository) {
		return new GetAllUsers(repository);
	}

	private GetAllUsers(final UsersRepository repository) {
		this.repository = repository;
	}

	@Override
	public List<User> execute(final Void param) {
		final List<User> users = repository.getAllUsers();
		users.sort(Comparator.comparing(User::getId));
		return users;
	}
}