package mx.edu.utp.demospring.student.adapter;

@FunctionalInterface
public interface PdfGenerator<I, O> {
	O generate(I input);
}