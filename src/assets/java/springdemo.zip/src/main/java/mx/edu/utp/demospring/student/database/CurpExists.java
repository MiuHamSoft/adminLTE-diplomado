package mx.edu.utp.demospring.student.database;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.Predicate;

final class CurpExists implements Predicate<String> {

	private static final String QUERY =
			"select count(*) from curso.students where curp = ?";
	private final JdbcTemplate template;

	private CurpExists(final JdbcTemplate template) {
		this.template = template;
	}

	static Predicate<String> create(final JdbcTemplate template) {
		return new CurpExists(template);
	}

	@Override
	public boolean test(final String curp) {
		final Integer count = template.queryForObject(
				QUERY,
				Integer.class,
				curp
		);
		return count >= 1;
	}
}