package mx.edu.utp.demospring.users.database;

import mx.edu.utp.demospring.users.domain.User;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.Predicate;
import java.util.function.UnaryOperator;

public final class CreateUser implements Predicate<User> {

	public static final String QUERY = "INSERT INTO curso.users " +
			"(username, hash, first_name, fathers_last_name, mothers_last_name, id_role) " +
			"VALUES(?, ?, ?, ?, ?, ?);";
	private final JdbcTemplate template;
	private final UnaryOperator<String> passwordEncoder;

	public static Predicate<User> create(
			final JdbcTemplate template,
			final UnaryOperator<String> passwordEncoder) {
		return new CreateUser(template, passwordEncoder);
	}

	private CreateUser(final JdbcTemplate template, final UnaryOperator<String> passwordEncoder) {
		this.template = template;
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	public boolean test(final User user) {
		final String password = user.getPassword();
		final String hash = passwordEncoder.apply(password);

		final int result = template.update(
				QUERY,
				user.getUsername(),
				hash,
				user.getFirstName(),
				user.getFathersLastName(),
				user.getMothersLastName(),
				user.getIdRole()
		);
		return result >= 1;
	}
}