package mx.edu.utp.demospring.student.database;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.Predicate;

final class DeleteStudentWithId implements Predicate<String> {

	private static final String QUERY = "DELETE FROM curso.students WHERE id = ?;";
	private final JdbcTemplate template;

	static Predicate<String> create(final JdbcTemplate template) {
		return new DeleteStudentWithId(template);
	}

	private DeleteStudentWithId(final JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public boolean test(final String idStudent) {
		final int results = template.update(
				QUERY,
				idStudent
		);
		return results >= 1;
	}
}