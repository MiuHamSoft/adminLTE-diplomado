package mx.edu.utp.demospring.student.database;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.Predicate;

final class StudentExistsWithId implements Predicate<String> {

	private static final String QUERY =
			"select count(*) from curso.students where id = ?";
	private final JdbcTemplate template;

	private StudentExistsWithId(final JdbcTemplate template) {
		this.template = template;
	}

	static Predicate<String> create(final JdbcTemplate template) {
		return new StudentExistsWithId(template);
	}

	@Override
	public boolean test(final String idStudent) {
		final Integer count = template.queryForObject(
				QUERY,
				Integer.class,
				idStudent
		);
		return count >= 1;
	}
}