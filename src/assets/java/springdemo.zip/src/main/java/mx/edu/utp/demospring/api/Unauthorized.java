package mx.edu.utp.demospring.api;

import org.springframework.http.HttpStatus;

import java.util.Collections;
import java.util.List;

public final class Unauthorized<T extends Exception> implements JSend<T> {

	private final String status = HttpStatus.UNAUTHORIZED.toString();
	private final int code = HttpStatus.UNAUTHORIZED.value();
	private final String message;

	private Unauthorized(final T data) {
		message = data.getLocalizedMessage();
	}

	static <T extends Exception> JSend<T> create(final T data) {
		return new Unauthorized<>(data);
	}

	@Override
	public String getStatus() {
		return status;
	}

	@Override
	public int getCode() {
		return code;
	}

	@Override
	public T getData() {
		return null;
	}

	@Override
	public String getMessage() {
		return message;
	}

	@Override
	public List<String> getStack() {
		return Collections.emptyList();
	}
}