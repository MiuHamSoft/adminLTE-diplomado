package mx.edu.utp.demospring.users.config;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.users.database.UsersJdbcRepository;
import mx.edu.utp.demospring.users.database.UsersRepository;
import mx.edu.utp.demospring.users.domain.User;
import mx.edu.utp.demospring.users.usecase.CreateUser;
import mx.edu.utp.demospring.users.usecase.GetAllUsers;
import mx.edu.utp.demospring.utils.PasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.List;
import java.util.function.UnaryOperator;

@Configuration
public class UsersConfig {

	@Autowired
	private DataSource dataSource;

	private UsersRepository repository;

	@PostConstruct
	public void postConstruct() {
		final JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		final UnaryOperator<String> passwordEncoder = PasswordEncoder.create();
		repository = UsersJdbcRepository.create(jdbcTemplate, passwordEncoder);
	}

	@Bean
	public UseCase<User, String> createUser() {
		return CreateUser.create(repository);
	}

	@Bean
	public UseCase<Void, List<User>> getAllUsers() {
		return GetAllUsers.create(repository);
	}
}