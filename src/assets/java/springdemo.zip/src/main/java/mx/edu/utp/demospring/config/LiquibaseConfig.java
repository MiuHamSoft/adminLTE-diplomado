package mx.edu.utp.demospring.config;

import liquibase.integration.spring.SpringLiquibase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class LiquibaseConfig {

	@Autowired
	private DataSource dataSource;

	@Bean
	public SpringLiquibase liquibaseTest() {
		final SpringLiquibase liquibase = new SpringLiquibase();
		liquibase.setChangeLog("classpath:liquibase-changeLog.sql");
		liquibase.setDataSource(dataSource);
		return liquibase;
	}
}