package mx.edu.utp.demospring.student.domain;

public final class GroupImpl implements Group {

	private final int id;
	private final int semester;
	private final char letter;

	@SuppressWarnings("PublicConstructor")
	public static final class Builder {

		private int id;
		private int semester;
		private char letter;

		public Builder id(final int id) {
			this.id = id;
			return this;
		}

		public Builder semester(final int semester) {
			this.semester = semester;
			return this;
		}

		public Builder letter(final char letter) {
			this.letter = letter;
			return this;
		}

		public Builder letter(final CharSequence letter) {
			this.letter = letter.charAt(0);
			return this;
		}

		public Group build() {
			return new GroupImpl(this);
		}
	}

	public static Builder builder() {
		return new Builder();
	}

	private GroupImpl(final Builder builder) {
		id = builder.id;
		semester = builder.semester;
		letter = builder.letter;
	}

	@Override
	public int getSemester() {
		return semester;
	}

	@Override
	public char getLetter() {
		return letter;
	}

	@Override
	public int getId() {
		return id;
	}
}