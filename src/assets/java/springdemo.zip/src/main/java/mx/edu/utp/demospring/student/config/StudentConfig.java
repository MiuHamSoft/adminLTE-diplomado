package mx.edu.utp.demospring.student.config;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.adapter.PdfGenerator;
import mx.edu.utp.demospring.student.adapter.PdfStudentsGenerator;
import mx.edu.utp.demospring.student.database.StudentJdbcRepository;
import mx.edu.utp.demospring.student.database.StudentRepository;
import mx.edu.utp.demospring.student.domain.Student;
import mx.edu.utp.demospring.student.domain.StudentMapper;
import mx.edu.utp.demospring.student.usecase.CreateStudent;
import mx.edu.utp.demospring.student.usecase.DeleteStudentWithId;
import mx.edu.utp.demospring.student.usecase.GetAllStudents;
import mx.edu.utp.demospring.student.usecase.GetStudentWithCurp;
import mx.edu.utp.demospring.student.usecase.GetStudentWithId;
import mx.edu.utp.demospring.student.usecase.UpdateStudent;
import mx.edu.utp.demospring.utils.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.List;

@Configuration
public class StudentConfig {

	private StudentRepository repository;

	@Autowired
	private DataSource dataSource;

	@PostConstruct
	public void postConstruct() {
		final JdbcTemplate template = new JdbcTemplate(dataSource);
		repository = StudentJdbcRepository.create(template);
	}

	@Bean
	public UseCase<String, Student> getStudentWithId() {
		return GetStudentWithId.create(repository);
	}

	@Bean
	public UseCase<Student, String> createStudent() {
		return CreateStudent.create(repository);
	}

	@Bean
	public static Mapper<String, Student> getStudentMapper() {
		return StudentMapper.create();
	}

	@Bean
	public UseCase<Student, String> updateStudent() {
		return UpdateStudent.create(repository);
	}

	@Bean
	public UseCase<String, Student> getStudentWithCurp() {
		return GetStudentWithCurp.create(repository);
	}

	@Bean
	public UseCase<Void, List<Student>> getAllStudents() {
		return GetAllStudents.create(repository);
	}

	@Bean
	public UseCase<String, String> deleteStudentWithId() {
		return DeleteStudentWithId.create(repository);
	}

	@Bean
	public static PdfGenerator<List<Student>, String> pdfStudentsGenerator() {
		return PdfStudentsGenerator.create();
	}
}