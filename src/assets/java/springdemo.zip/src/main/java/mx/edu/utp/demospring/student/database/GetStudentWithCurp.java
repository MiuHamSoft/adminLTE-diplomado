package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Gender;
import mx.edu.utp.demospring.student.domain.Student;
import mx.edu.utp.demospring.student.domain.StudentImpl;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Map;
import java.util.function.Function;

final class GetStudentWithCurp implements Function<String, Student> {

	private static final String QUERY =
			"SELECT id, serial, first_name, last_name, curp, gender, yearofbirth, id_group " +
					"FROM curso.students where curp = ?;";
	private final JdbcTemplate template;

	static Function<String, Student> create(final JdbcTemplate template) {
		return new GetStudentWithCurp(template);
	}

	private GetStudentWithCurp(final JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public Student apply(final String curp) {
		final Map<String, Object> row = template.queryForMap(
				QUERY,
				curp
		);

		final String id = (String) row.get("id");
		final String firstName = (String) row.get("first_name");
		final String lastName = (String) row.get("last_name");
		final CharSequence genderAsChar = (CharSequence) row.get("gender");
		final Gender gender = Gender.getValueOf(genderAsChar.charAt(0));
		final int yearOfBirth = (int) row.get("yearOfBirth");

		return StudentImpl.builder()
				.id(id)
				.curp(curp)
				.firstName(firstName)
				.lastName(lastName)
				.gender(gender)
				.yearOfBirth(yearOfBirth)
				.build();
	}
}