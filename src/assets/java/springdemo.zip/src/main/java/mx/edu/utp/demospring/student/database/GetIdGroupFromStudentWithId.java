package mx.edu.utp.demospring.student.database;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.ToIntFunction;

final class GetIdGroupFromStudentWithId implements ToIntFunction<String> {

	private static final String QUERY =
			"select id_group from curso.students where id = ?";
	private final JdbcTemplate template;

	static ToIntFunction<String> create(final JdbcTemplate template) {
		return new GetIdGroupFromStudentWithId(template);
	}

	private GetIdGroupFromStudentWithId(final JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public int applyAsInt(final String idStudent) {
		return template.queryForObject(
				QUERY,
				Integer.class,
				idStudent
		);
	}
}