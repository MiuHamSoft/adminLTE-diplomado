package mx.edu.utp.demospring.users.domain;

public interface User {
	int getId();
	String getUsername();
	String getFirstName();
	String getFathersLastName();
	String getMothersLastName();
	String getFullName();
	String getPassword();
	int getIdRole();
	String getRole();
	String getToken();
}