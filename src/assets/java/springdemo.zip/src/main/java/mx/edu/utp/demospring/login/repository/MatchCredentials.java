package mx.edu.utp.demospring.login.repository;

import mx.edu.utp.demospring.users.domain.User;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.BiPredicate;
import java.util.function.Predicate;

final class MatchCredentials implements Predicate<User> {

	private static final String QUERY = "SELECT hash FROM users WHERE username = ?";
	private final JdbcTemplate template;
	private final BiPredicate<? super String, ? super String> passwordComparator;

	static Predicate<User> create(
			final JdbcTemplate template,
			final BiPredicate<? super String, ? super String> passwordComparator) {
		return new MatchCredentials(template, passwordComparator);
	}

	private MatchCredentials(
			final JdbcTemplate template,
			final BiPredicate<? super String, ? super String> passwordComparator) {
		this.template = template;
		this.passwordComparator = passwordComparator;
	}

	@Override
	public boolean test(final User user) {
		final String hash = template.queryForObject(
				QUERY,
				String.class,
				user.getUsername()
		);
		return passwordComparator.test(user.getPassword(), hash);
	}
}