package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Student;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.Predicate;

final class UpdateStudent implements Predicate<Student> {

	private static final String QUERY =
			"UPDATE curso.students " +
			"SET first_name=?, last_name=?, curp=?, gender=?, yearofbirth=?, id_group=? " +
			"WHERE id=?;";

	private final JdbcTemplate template;

	static Predicate<Student> create(final JdbcTemplate template) {
		return new UpdateStudent(template);
	}

	private UpdateStudent(final JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public boolean test(final Student student) {
		final int results = template.update(
				QUERY,
				student.getFirstName(),
				student.getLastName(),
				student.getCurp(),
				student.getGenderAsString(),
				student.getYearOfBirth(),
				student.getIdGroup(),
				student.getId()
		);
		return results >= 1;
	}
}