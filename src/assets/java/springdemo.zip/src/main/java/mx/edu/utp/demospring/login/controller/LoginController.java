package mx.edu.utp.demospring.login.controller;

import mx.edu.utp.demospring.api.JSend;
import mx.edu.utp.demospring.api.Success;
import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.users.domain.User;
import mx.edu.utp.demospring.users.domain.UserImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public final class LoginController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);
	private static final String LOGIN = "/api/v1/public/login/";

	@Autowired
	private UseCase<User, User> authenticateUser;

	@PostMapping(LOGIN)
	public JSend<User> login(@RequestBody final UserImpl user) {
		LOGGER.debug(user.toString());
		final User userWithToken = authenticateUser.execute(user);

		return Success.<User>builder()
				.data(userWithToken)
				.message("El usuario se logueo con exito")
				.build();
	}
}