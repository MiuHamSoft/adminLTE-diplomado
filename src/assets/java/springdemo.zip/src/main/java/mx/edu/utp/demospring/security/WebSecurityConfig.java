package mx.edu.utp.demospring.security;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@EnableWebSecurity
@Configurable
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	private static final String ADMIN = "ADMIN";
	private static final String TEACHER = "TEACHER";

	private static final String AUTH_HEADER = "x-auth-token";
	private static final List<String> ALLOWED_HEADERS = Arrays.asList(
			"Accept",
			"Access-Control-Allow-Origin",
			"Access-Control-Request-Headers",
			"Authorization",
			"Cache-Control",
			"Content-Length",
			"Content-Type",
			"Origin",
			"X-Auth-Token",
			"X-Requested-With"
	);

	@Override
	public void configure(final WebSecurity web) {
		web.ignoring()
				.antMatchers(HttpMethod.POST, "/api/v1/public/**");
	}

	@Override
	protected void configure(final HttpSecurity http) throws Exception {
		http
				.cors()
				.and()
				.csrf()
				.disable()
				.authorizeRequests()
				.antMatchers(HttpMethod.GET, "/api/v1/secure/students/pdf/")
				.hasAnyRole(ADMIN, TEACHER)
				.antMatchers(HttpMethod.DELETE, "/api/v1/secure/students/**")
				.hasRole(ADMIN)
				.antMatchers("/api/v1/secure/users/").hasRole(ADMIN)
				.antMatchers(HttpMethod.POST, "/api/v1/public/**").permitAll()
				.anyRequest().authenticated()
				.and()
				.addFilterBefore(
						JwtFilter.create(
								"/api/v1/secure/**",
								JwtServiceImpl.create(),
								AUTH_HEADER
						),
						UsernamePasswordAuthenticationFilter.class
				);
	}

	@Bean
	static CorsConfigurationSource corsConfigurationSource() {
		final CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowCredentials(true);
		configuration.addAllowedOrigin("*");
		configuration.setAllowedHeaders(ALLOWED_HEADERS);
		configuration.addAllowedMethod("*");
		configuration.setExposedHeaders(Collections.singletonList(AUTH_HEADER));
		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}
}