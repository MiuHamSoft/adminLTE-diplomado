package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Group;
import mx.edu.utp.demospring.student.domain.Student;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;

public final class StudentJdbcRepository implements StudentRepository {

	private final JdbcTemplate template;

	private StudentJdbcRepository(final JdbcTemplate template) {
		this.template = template;
	}

	public static StudentRepository create(final JdbcTemplate template) {
		return new StudentJdbcRepository(template);
	}

	@Override
	public boolean curpExists(final String curp) {
		final Predicate<String> curpExists = CurpExists.create(template);
		return curpExists.test(curp);
	}

	@Override
	public boolean insertStudent(final Student student) {
		final Predicate<Student> insertStudent = InsertStudent.create(template);
		return insertStudent.test(student);
	}

	@Override
	public Student getStudentWithId(final String idStudent) {
		final Function<String, Student> getStudentWithId = GetStudentWithId.create(template);
		return getStudentWithId.apply(idStudent);
	}

	@Override
	public boolean studentExistsWithId(final String idStudent) {
		final Predicate<String> studentExistsWithId = StudentExistsWithId.create(template);
		return studentExistsWithId.test(idStudent);
	}

	@Override
	public boolean updateStudent(final Student student) {
		final Predicate<Student> updateStudent = UpdateStudent.create(template);
		return updateStudent.test(student);
	}

	@Override
	public boolean studentExistsWithCurp(final String curp) {
		final Predicate<String> studentExistsWithCurp = StudentExistsWithCurp.create(template);
		return studentExistsWithCurp.test(curp);
	}

	@Override
	public Student getStudentWithCurp(final String curp) {
		final Function<String, Student> getStudentWithCurp = GetStudentWithCurp.create(template);
		return getStudentWithCurp.apply(curp);
	}

	@Override
	public Group getGroupWithId(final int idGroup) {
		final IntFunction<Group> getGroupWithId = GetGroupWithId.create(template);
		return getGroupWithId.apply(idGroup);
	}

	@Override
	public int getIdGroupFromStudentWithId(final String idStudent) {
		final ToIntFunction<String> getIdGroupFromStudentWithId =
				GetIdGroupFromStudentWithId.create(template);
		return getIdGroupFromStudentWithId.applyAsInt(idStudent);
	}

	@Override
	public List<Student> getAllStudents() {
		final Function<Void, List<Student>> getAllStudents = GetAllStudents.create(template);
		return getAllStudents.apply(null);
	}

	@Override
	public boolean deleteStudentWithId(final String idStudent) {
		final Predicate<String> deleteStudentWithId = DeleteStudentWithId.create(template);
		return deleteStudentWithId.test(idStudent);
	}
}