package mx.edu.utp.demospring.login.usecase;

import mx.edu.utp.demospring.api.UnauthorizedException;
import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.login.repository.LoginRepository;
import mx.edu.utp.demospring.users.domain.User;
import mx.edu.utp.demospring.users.domain.UserImpl;

import java.util.Objects;

public final class AuthenticateUser implements UseCase<User, User> {

	private final LoginRepository repository;
	private User user;

	private AuthenticateUser(final LoginRepository repository) {
		this.repository = repository;
	}

	public static UseCase<User, User> create(final LoginRepository repository) {
		return new AuthenticateUser(repository);
	}

	@Override
	public User execute(final User user) {
		setUser(user);
		verifyIfUserExists();
		matchCredentials();
		getUser();
		return getUserWithToken();
	}

	private void setUser(final User user) {
		this.user = Objects.requireNonNull(user, "Usuario vacio");
	}

	private void verifyIfUserExists() {
		final boolean exists = repository.userExistsWithUsername(getUsername());

		if (!exists) {
			throwUnauthorizedException();
		}
	}

	private static void throwUnauthorizedException() {
		throw UnauthorizedException.create(getFailureMessage());
	}

	private static String getFailureMessage() {
		return "Usuario y/o contraseña invalidos";
	}

	private void matchCredentials() {
		final boolean match = repository.matchCredentials(user);

		if (!match) {
			throwUnauthorizedException();
		}
	}

	private void getUser() {
		user = repository.getUserWithUsername(getUsername());
	}

	private String getUsername() {
		return user.getUsername();
	}

	private User getUserWithToken() {
		final String token = repository.getToken(user);

		return new UserImpl.Builder()
				.from(user)
				.token(token)
				.build();
	}
}