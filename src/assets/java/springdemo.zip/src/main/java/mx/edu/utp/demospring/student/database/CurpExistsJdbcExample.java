package mx.edu.utp.demospring.student.database;

import org.slf4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static org.slf4j.LoggerFactory.getLogger;

final class CurpExistsJdbcExample {

	private static final Logger LOGGER = getLogger(CurpExistsJdbcExample.class);

	public static void main(final String[] args) {
		final CurpExistsJdbcExample curpExists = create();
		CurpExistsJdbcExample.exists("ABC");
	}

	private CurpExistsJdbcExample() {
	}

	private static CurpExistsJdbcExample create() {
		return new CurpExistsJdbcExample();
	}

	private static boolean exists(final String curp) {
		try {
			Class.forName("org.postgresql.Driver");
			// sonoo is the database name, root is the username and password both.
			//"jdbc:mysql://localhost:3306/sonoo","root","root")
			final String url = "jdbc:postgresql://localhost:5432/postgres?currentSchema=test";
			final String user = "luminiso";
			final String password = "PrgwwNRDC9ftrApSdj21";
			final Connection connection = DriverManager.getConnection(
					url,
					user,
					password
			);
			final Statement statement = connection.createStatement();
			final ResultSet resultSet = statement.executeQuery(
					"SELECT curp, serial FROM test.student"
			);

			while (resultSet.next()) {
				LOGGER.info("Curp: {}", resultSet.getString(1));
				LOGGER.info("Serial: {}", resultSet.getLong(2));
			}
			return true;
		} catch (final ClassNotFoundException | SQLException e) {
			LOGGER.error(getFailureMessage(curp), e);
		}
		throw new RuntimeException(getFailureMessage(curp));
	}

	private static String getFailureMessage(final String curp) {
		return String.format("Hubo un error al verificar al alumno con curp: %s", curp);
	}
}