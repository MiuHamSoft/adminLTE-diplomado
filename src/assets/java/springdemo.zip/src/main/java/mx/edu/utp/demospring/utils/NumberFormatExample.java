package mx.edu.utp.demospring.utils;

import org.slf4j.Logger;

import java.text.NumberFormat;
import java.util.Locale;

import static org.slf4j.LoggerFactory.getLogger;

public enum NumberFormatExample {
	;

	private static final Logger LOGGER = getLogger(NumberFormatExample.class);
	public static final long NUMBER = 1_000_000L;
	public static final long CURRENCY = 1_000_000L;
	public static final double PERCENTAGE = 0.10;

	public static void main(final String[] args) {
		final Locale esMx = new Locale("es", "MX");

		final NumberFormat numberFormat = NumberFormat.getNumberInstance(esMx);
		final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(esMx);
		final NumberFormat percentageFormat = NumberFormat.getPercentInstance(esMx);

		LOGGER.info("{}", numberFormat.format(NUMBER));
		LOGGER.info("{}", currencyFormat.format(CURRENCY));
		LOGGER.info("{}", percentageFormat.format(PERCENTAGE));
	}
}