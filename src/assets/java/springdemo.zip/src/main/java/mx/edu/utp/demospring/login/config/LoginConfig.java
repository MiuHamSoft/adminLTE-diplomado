package mx.edu.utp.demospring.login.config;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.login.repository.LoginJdbcRepository;
import mx.edu.utp.demospring.login.repository.LoginRepository;
import mx.edu.utp.demospring.login.usecase.AuthenticateUser;
import mx.edu.utp.demospring.security.JwtService;
import mx.edu.utp.demospring.security.JwtServiceImpl;
import mx.edu.utp.demospring.users.domain.User;
import mx.edu.utp.demospring.utils.PasswordComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.function.BiPredicate;

@Configuration
public class LoginConfig {

	@Autowired
	private DataSource dataSource;

	private LoginRepository repository;

	@PostConstruct
	public void postConstruct() {
		final JdbcTemplate template = new JdbcTemplate(dataSource);
		final JwtService jwtService = JwtServiceImpl.create();
		final BiPredicate<String, String> passwordComparator = PasswordComparator.create();
		repository = LoginJdbcRepository.create(template, jwtService, passwordComparator);
	}

	@Bean
	public UseCase<User, User> authenticateUser() {
		return AuthenticateUser.create(repository);
	}
}