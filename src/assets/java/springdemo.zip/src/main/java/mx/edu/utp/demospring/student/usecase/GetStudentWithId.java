package mx.edu.utp.demospring.student.usecase;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.database.StudentRepository;
import mx.edu.utp.demospring.student.domain.Student;

public final class GetStudentWithId implements UseCase<String, Student> {

	private final StudentRepository repository;

	private String id;

	public static UseCase<String, Student> create(final StudentRepository repository) {
		return new GetStudentWithId(repository);
	}

	private GetStudentWithId(final StudentRepository repository) {
		this.repository = repository;
	}

	@Override
	public Student execute(final String id) {
		setId(id);
		verifyIfStudentExists();
		return getStudentWithId();

	}

	private void setId(final String id) {
		this.id = id;
	}

	private void verifyIfStudentExists() {
		final boolean exists = repository.studentExistsWithId(id);

		if (!exists) {
			throw new IllegalArgumentException(getNonExistentStudentWarning(id));
		}
	}

	private static String getNonExistentStudentWarning(final String id) {
		return String.format("No existe el estudiante con id: %s", id);
	}

	private Student getStudentWithId() {
		return repository.getStudentWithId(id);
	}
}