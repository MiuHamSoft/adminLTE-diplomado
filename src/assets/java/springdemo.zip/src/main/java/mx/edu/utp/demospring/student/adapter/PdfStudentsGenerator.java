package mx.edu.utp.demospring.student.adapter;

import com.github.javafaker.Faker;
import mx.edu.utp.demospring.student.domain.Student;
import mx.edu.utp.demospring.student.domain.StudentImpl;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.slf4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import static org.slf4j.LoggerFactory.getLogger;

public final class PdfStudentsGenerator implements PdfGenerator<List<Student>, String> {

	private static final Logger LOGGER = getLogger(PdfStudentsGenerator.class);
	private static final int NUMBER_OF_STUDENTS = 20;
	private static final float FONT_SIZE = 12.0F;
	private static final float Y_OFFSET = 10.0F;
	private static final float X_OFFSET = 25.0F;
	private static final float INIT_Y_OFFSET = 750.0F;

	private PDDocument document;
	private List<Student> students;

	private PdfStudentsGenerator() {
	}

	public static PdfGenerator<List<Student>, String> create() {
		return new PdfStudentsGenerator();
	}

	public static void main(final String[] args) {
		final List<Student> students = getStudents();
		final PdfGenerator<List<Student>, String> pdfStudent = create();
		LOGGER.info(pdfStudent.generate(students));
	}

	private static List<Student> getStudents() {
		final Locale esMx = new Locale("es", "MX");
		final Faker faker = new Faker(esMx);

		final List<Student> students = new ArrayList<>(NUMBER_OF_STUDENTS);
		for (int i = 0; i < NUMBER_OF_STUDENTS; i++) {

			final String id = getId(faker);
			final Student student = StudentImpl.builder()
					.firstName(faker.name().firstName())
					.lastName(faker.name().lastName())
					.id(id)
					.build();
			students.add(student);
		}

		students.sort(
				Comparator.comparing(Student::getLastName)
						.thenComparing(Student::getFirstName));
		return students;
	}

	private static String getId(final Faker faker) {
		final String id = faker.lorem().characters(10);
		return String.format("utp%s", id);
	}

	@Override
	public String generate(final List<Student> students) {
		setStudents(students);
		createDocument();
		final PDPage page = createPage();
		addStudentsData(page);
		saveDocumentToHdd();
		return getDocumentAsBase64();
	}

	public void setStudents(final List<? extends Student> students) {
		this.students = Collections.unmodifiableList(students);
	}

	private String getDocumentAsBase64() {
		final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		try {
			document.save(bytes);
		} catch (final IOException e) {
			throw new UncheckedIOException(e);
		}
		return Base64.getEncoder().encodeToString(bytes.toByteArray());
	}

	private void saveDocumentToHdd() {
		try {
			document.save("students.pdf");
		} catch (final IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	private void addStudentsData(final PDPage page) {
		try {
			final PDPageContentStream contentStream = new PDPageContentStream(document, page);
			contentStream.setFont(PDType1Font.COURIER, FONT_SIZE);

			float yOffset = INIT_Y_OFFSET;
			for (final Student student : students) {
				setStudentData(contentStream, yOffset, student);
				yOffset -= Y_OFFSET;
			}
			contentStream.close();
		} catch (final IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	private void createDocument() {
		document = new PDDocument();
	}

	private PDPage createPage() {
		final PDPage page = new PDPage();
		document.addPage(page);
		return page;
	}

	private static void setStudentData(
			final PDPageContentStream contentStream,
			final float yOffset,
			final Student student) throws IOException {
		contentStream.beginText();
		contentStream.newLineAtOffset(X_OFFSET, yOffset);
		contentStream.showText(String.valueOf(student.getId()));
		contentStream.showText(": ");
		contentStream.showText(student.getFirstName());
		contentStream.showText(" ");
		contentStream.showText(student.getLastName());
		contentStream.showText(" ");
		contentStream.endText();
	}

}