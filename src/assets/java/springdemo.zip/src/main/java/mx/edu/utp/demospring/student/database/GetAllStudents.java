package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Gender;
import mx.edu.utp.demospring.student.domain.Group;
import mx.edu.utp.demospring.student.domain.GroupImpl;
import mx.edu.utp.demospring.student.domain.Student;
import mx.edu.utp.demospring.student.domain.StudentImpl;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public final class GetAllStudents implements Function<Void,List<Student>> {

	private static final String QUERY =
			"SELECT id, serial, first_name, last_name, curp, gender, yearofbirth, id_group, letter, semester " +
					"FROM curso.students_groups_view;";
	private final JdbcTemplate template;

	public static Function<Void,List<Student>> create(final JdbcTemplate template) {
		return new GetAllStudents(template);
	}

	private GetAllStudents(final JdbcTemplate template) {
		this.template = template;
	}

	private static Student getStudent(final Map<String, Object> row) {
		final String id = (String) row.get("id");
		final String firstName = (String) row.get("first_name");
		final String lastName = (String) row.get("last_name");
		final String curp = (String) row.get("curp");
		final CharSequence genderAsChar = (CharSequence) row.get("gender");
		final Gender gender = Gender.getValueOf(genderAsChar.charAt(0));
		final int yearOfBirth = (int) row.get("yearOfBirth");
		final int idGroup = (int) row.get("id_group");
		final int semester = (int) row.get("semester");
		final CharSequence letter = (CharSequence) row.get("letter");

		final Group group = GroupImpl.builder()
				.id(idGroup)
				.letter(letter)
				.semester(semester)
				.build();

		return StudentImpl.builder()
				.id(id)
				.curp(curp)
				.firstName(firstName)
				.lastName(lastName)
				.gender(gender)
				.yearOfBirth(yearOfBirth)
				.group(group)
				.build();

	}

	@Override
	public List<Student> apply(final Void unused) {
		final List<Student> students = new ArrayList<>(20);

		final List<Map<String, Object>> rows = template.queryForList(
				QUERY
		);

		for (final Map<String, Object> row : rows) {
			final Student student = getStudent(row);
			students.add(student);
		}
		return students;
	}
}