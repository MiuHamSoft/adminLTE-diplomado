package mx.edu.utp.demospring.login.repository;

import mx.edu.utp.demospring.users.domain.User;

public interface LoginRepository {
	boolean userExistsWithUsername(String username);
	boolean matchCredentials(User user);
	User getUserWithUsername(String username);
	String getToken(User user);
}