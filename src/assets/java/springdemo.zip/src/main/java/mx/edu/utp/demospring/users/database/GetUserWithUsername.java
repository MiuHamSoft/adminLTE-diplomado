package mx.edu.utp.demospring.users.database;

import mx.edu.utp.demospring.users.domain.User;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.Function;

public final class GetUserWithUsername implements Function<String, User> {

	private static final String QUERY =
			"SELECT ID, USERNAME, FIRST_NAME, FATHERS_LAST_NAME,MOTHERS_LAST_NAME, ID_ROLE, ROLE " +
					"FROM users_roles_view " +
					"WHERE username = ?";
	private final JdbcTemplate template;

	private GetUserWithUsername(final JdbcTemplate template) {
		this.template = template;
	}

	public static Function<String, User> create(final JdbcTemplate template) {
		return new GetUserWithUsername(template);
	}

	@Override
	public User apply(final String username) {
		return template.queryForObject(
				QUERY,
				UsersMapper.create(),
				username
		);
	}
}