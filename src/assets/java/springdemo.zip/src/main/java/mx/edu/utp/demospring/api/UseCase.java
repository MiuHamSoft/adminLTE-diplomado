package mx.edu.utp.demospring.api;

@FunctionalInterface
public interface UseCase <I, O>{
	O execute(I param);
}