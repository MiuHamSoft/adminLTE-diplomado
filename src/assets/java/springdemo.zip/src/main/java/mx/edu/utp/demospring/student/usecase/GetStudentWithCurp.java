package mx.edu.utp.demospring.student.usecase;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.database.StudentRepository;
import mx.edu.utp.demospring.student.domain.Group;
import mx.edu.utp.demospring.student.domain.Student;
import mx.edu.utp.demospring.student.domain.StudentImpl;

public final class GetStudentWithCurp implements UseCase<String, Student> {

	private final StudentRepository repository;

	private String curp;
	private Student student;
	private Group group;

	private GetStudentWithCurp(final StudentRepository repository) {
		this.repository = repository;
	}

	public static UseCase<String, Student> create(final StudentRepository repository) {
		return new GetStudentWithCurp(repository);
	}

	@Override
	public Student execute(final String curp) {
		setCurp(curp);
		verifyIfStudentExistsWithCurp();
		getStudentFromRepository();
		setGroup();
		return getStudent();
	}

	public void setCurp(final String curp) {
		this.curp = curp;
	}

	private void verifyIfStudentExistsWithCurp() {
		final boolean exists = repository.studentExistsWithCurp(curp);

		if (!exists) {
			throw new IllegalArgumentException(getNonExistentStudentWarning(curp));
		}
	}

	private static String getNonExistentStudentWarning(final String curp) {
		return String.format("No existe el estudiante con curp %s", curp);
	}

	private void getStudentFromRepository() {
		student = repository.getStudentWithCurp(curp);
	}

	private void setGroup() {
		final int idGroup = repository.getIdGroupFromStudentWithId(student.getId());
		group = repository.getGroupWithId(idGroup);
	}

	private Student getStudent() {
		return StudentImpl.builder()
				.from(student)
				.group(group)
				.build();
	}
}