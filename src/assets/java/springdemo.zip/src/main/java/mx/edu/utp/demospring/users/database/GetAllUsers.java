package mx.edu.utp.demospring.users.database;


import mx.edu.utp.demospring.users.domain.User;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.function.Function;

public final class GetAllUsers implements Function<Void, List<User>> {

	private static final String QUERY =
			"SELECT id, username, hash, first_name, fathers_last_name, mothers_last_name, id_role, role, active " +
			"FROM curso.users_roles_view;";
	private final JdbcTemplate template;

	private GetAllUsers(final JdbcTemplate template) {
		this.template = template;
	}

	public static Function<Void, List<User>> create(final JdbcTemplate template) {
		return new GetAllUsers(template);
	}

	@Override
	public List<User> apply(final Void unused) {
		return template.query(
				QUERY,
				UsersMapper.create()
		);
	}
}