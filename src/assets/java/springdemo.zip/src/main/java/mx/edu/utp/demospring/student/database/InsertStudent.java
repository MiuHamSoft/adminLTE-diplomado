package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Student;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.function.Predicate;

final class InsertStudent implements Predicate<Student> {

	private static final String QUERY =
			"INSERT INTO curso.students " +
			"(id, first_name, last_name, curp, gender, yearofbirth, id_group) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?);";
	private final JdbcTemplate template;

	static Predicate<Student> create(final JdbcTemplate template) {
		return new InsertStudent(template);
	}

	private InsertStudent(final JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public boolean test(final Student student) {
		final int results = template.update(
				QUERY,
				student.getId(),
				student.getFirstName(),
				student.getLastName(),
				student.getCurp(),
				student.getGenderAsString(),
				student.getYearOfBirth(),
				student.getIdGroup()
		);
		return results >= 1;
	}
}