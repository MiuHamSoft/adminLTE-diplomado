package mx.edu.utp.demospring.student.domain;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import mx.edu.utp.demospring.utils.Mapper;
import org.slf4j.Logger;

import static org.slf4j.LoggerFactory.getLogger;

public final class StudentMapper implements Mapper<String, Student> {

	private static final Logger LOGGER = getLogger(StudentMapper.class);

	private StudentMapper() {
	}

	public static Mapper<String, Student> create() {
		return new StudentMapper();
	}

	@Override
	public Student from(final String json) {
		if (json.isBlank()) {
			throw new IllegalArgumentException(getEmptyMessage());
		}

		LOGGER.debug(json);

		final JsonElement parser = JsonParser.parseString(json);
		final JsonObject jsonObject = parser.getAsJsonObject();

		final String id = jsonObject.get("id").getAsString();
		final String curp = jsonObject.get("curp").getAsString();
		final String firstName = jsonObject.get("firstName").getAsString();
		final String lastName = jsonObject.get("lastName").getAsString();
		final int yearOfBirth = jsonObject.get("yearOfBirth").getAsInt();
		final String genderAsString = jsonObject.get("gender").getAsString();
		final Gender gender = getGender(genderAsString);
		final JsonObject groupAsObj = jsonObject.get("group").getAsJsonObject();
		final Group group = getGroup(groupAsObj);

		return StudentImpl.builder()
				.id(id)
				.curp(curp)
				.firstName(firstName)
				.lastName(lastName)
				.yearOfBirth(yearOfBirth)
				.gender(gender)
				.group(group)
				.build();
	}

	private static String getEmptyMessage() {
		return "El cuerpo de la peticion no puede ser vacio o nulo";
	}

	private static Group getGroup(final JsonObject jsonObject) {
		final int id = jsonObject.get("id").getAsInt();
		final int semester = jsonObject.get("semester").getAsInt();
		final String letterAsString = jsonObject.get("letter").getAsString();
		final char letter = letterAsString.charAt(0);

		return GroupImpl.builder()
				.id(id)
				.letter(letter)
				.semester(semester)
				.build();
	}

	private static Gender getGender(final String genderAsString) {
		return Gender.getValueOf(genderAsString);
	}
}