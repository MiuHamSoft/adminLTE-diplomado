package mx.edu.utp.demospring.student.database;

import mx.edu.utp.demospring.student.domain.Group;
import mx.edu.utp.demospring.student.domain.Student;

import java.util.List;

public interface StudentRepository {
	boolean curpExists(String curp);
	boolean insertStudent(Student student);
	Student getStudentWithId(String idStudent);
	boolean studentExistsWithId(String idStudent);
	boolean updateStudent(Student student);
	boolean studentExistsWithCurp(String curp);
	Student getStudentWithCurp(String curp);
	Group getGroupWithId(int idGroup);
	int getIdGroupFromStudentWithId(String idStudent);
	List<Student> getAllStudents();
	boolean deleteStudentWithId(String idStudent);
}