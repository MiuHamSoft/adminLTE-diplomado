package mx.edu.utp.demospring.student.domain;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public enum Gender {
	FEMALE("Mujer", 'M'),
	MALE("Hombre", 'H');

	private static final Map<String, Gender> stringValues = new HashMap<>(2);
	private static final Map<Character, Gender> charValues = new HashMap<>(2);
	private final String name;
	private final char abbreviation;

	static {
		for (final Gender gender : values()) {
			stringValues.put(gender.getNameAsUpperCase(), gender);
			charValues.put(gender.getAbbreviationAsUpperCase(), gender);
		}
	}

	Gender(final String name, final char abbreviation) {
		this.name = name;
		this.abbreviation = abbreviation;
	}

	public String getName() {
		return name;
	}

	public String getNameAsUpperCase() {
		return name.toUpperCase(Locale.US);
	}

	public char getAbbreviation() {
		return abbreviation;
	}

	private char getAbbreviationAsUpperCase() {
		return Character.toUpperCase(abbreviation);
	}

	public static Gender getValueOf(final String value) {
		final Gender gender = stringValues.get(value.toUpperCase(Locale.US));
		if (null == gender) {
			throw new IllegalArgumentException(getInvalidValueWarning(value));
		}
		return gender;
	}

	public static Gender getValueOf(final char value) {
		final Gender gender = charValues.get(Character.toUpperCase(value));
		if (null == gender) {
			throw new IllegalArgumentException(getInvalidValueWarning(String.valueOf(value)));
		}
		return gender;
	}

	private static String getInvalidValueWarning(final String value) {
		return String.format("No existe el genero con valor de: %s", value);
	}

	@Override
	public String toString() {
		return name.toUpperCase(Locale.US);
	}
}