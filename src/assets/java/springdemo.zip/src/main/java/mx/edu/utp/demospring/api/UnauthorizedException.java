package mx.edu.utp.demospring.api;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNAUTHORIZED)
public final class UnauthorizedException extends RuntimeException {

	private UnauthorizedException(final String message) {
		super(message);
	}

	public static RuntimeException create(final String message) {
		return new UnauthorizedException(message);
	}
}