package mx.edu.utp.demospring.student.usecase;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.database.StudentRepository;
import mx.edu.utp.demospring.student.domain.Student;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class GetAllStudents implements UseCase<Void, List<Student>> {

	private final StudentRepository repository;

	public static UseCase<Void, List<Student>> create(final StudentRepository repository) {
		return new GetAllStudents(repository);
	}

	private GetAllStudents(final StudentRepository repository) {
		this.repository = repository;
	}

	@Override
	public List<Student> execute(final Void param) {
		final List<Student> students = repository.getAllStudents();

		if (null == students || students.isEmpty()) {
			return Collections.emptyList();
		}

		students.sort(Comparator.comparing(Student::getLastName).thenComparing(Student::getFirstName));
		return students;
	}
}