package mx.edu.utp.demospring.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class PostgresConfig {

	private static final String DRIVER_CLASS_NAME = "org.postgresql.Driver";
	private static final String URL = "jdbc:postgresql://localhost:5432/postgres";
	private static final String USERNAME = "luminiso";
	private static final String PASSWORD = "PrgwwNRDC9ftrApSdj21";
	private static final String SCHEMA = "curso";
	private static final int POOL_SIZE = 2;
	private static final String TEST_QUERY = "SELECT 1";

	@Bean
	public static DataSource getDataSource() {
		final HikariDataSource dataSource = new HikariDataSource();
		dataSource.setDriverClassName(DRIVER_CLASS_NAME);
		dataSource.setJdbcUrl(URL);
		dataSource.setUsername(USERNAME);
		dataSource.setPassword(PASSWORD);
		dataSource.setSchema(SCHEMA);
		dataSource.setMaximumPoolSize(POOL_SIZE);
		dataSource.setPoolName(SCHEMA);
		dataSource.setConnectionTestQuery(TEST_QUERY);
		return dataSource;
	}
}