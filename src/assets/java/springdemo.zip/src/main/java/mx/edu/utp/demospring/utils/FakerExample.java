package mx.edu.utp.demospring.utils;

import com.github.javafaker.Faker;
import org.slf4j.Logger;

import java.util.Locale;

import static org.slf4j.LoggerFactory.getLogger;

public enum FakerExample {
	;

	private static final Logger LOGGER = getLogger(FakerExample.class);
	private static final int NUMBER_OF_EXAMPLES = 10;
	private static final int LOREM_IPSUM_LENGTH = 100;

	public static void main(final String[] args) {
		final Locale esMx = new Locale("es", "MX");
		final Faker faker = new Faker(esMx);

		for (int i = 0; i < NUMBER_OF_EXAMPLES; i++) {
			LOGGER.info(faker.name().firstName());
			LOGGER.info(faker.name().lastName());
			LOGGER.info(faker.name().username());
			LOGGER.info(faker.lorem().characters(LOREM_IPSUM_LENGTH));
		}
	}
}