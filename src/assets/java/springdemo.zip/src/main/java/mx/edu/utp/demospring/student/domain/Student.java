package mx.edu.utp.demospring.student.domain;

public interface Student {
	String getId();
	String getCurp();
	String getFirstName();
	String getLastName();
	Group getGroup();
	Gender getGender();
	int getYearOfBirth();
	String getGenderAsString();
	int getIdGroup();
}