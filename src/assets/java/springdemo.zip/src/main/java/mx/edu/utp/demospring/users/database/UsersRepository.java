package mx.edu.utp.demospring.users.database;

import mx.edu.utp.demospring.users.domain.User;

import java.util.List;

public interface UsersRepository {
	boolean createUser(User user);
	boolean userExistsWithUsername(String username);
	List<User> getAllUsers();
}