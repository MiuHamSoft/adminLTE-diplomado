package mx.edu.utp.demospring.student.usecase;

import mx.edu.utp.demospring.api.UseCase;
import mx.edu.utp.demospring.student.database.StudentRepository;
import mx.edu.utp.demospring.student.domain.Student;

public final class CreateStudent implements UseCase<Student, String> {

	private final StudentRepository repository;
	private Student student;

	private CreateStudent(final StudentRepository repository) {
		this.repository = repository;
	}

	public static UseCase<Student, String> create(final StudentRepository repository) {
		return new CreateStudent(repository);
	}

	@Override
	public String execute(final Student student) {
		setStudent(student);
		verifyIfCurpAlreadyExists();
		verifyIfIdAlreadyExists();
		tryToAddStudentToDb();
		return getSuccessMessage();
	}

	private void setStudent(final Student student) {
		this.student = student;
	}

	private void verifyIfCurpAlreadyExists() {
		final String curp = student.getCurp();
		final boolean exists = repository.curpExists(curp);

		if (exists) {
			throw new IllegalArgumentException(getCurpMessage());
		}
	}

	private static String getCurpMessage() {
		return "El curp ya se encuentra repetido";
	}

	private void verifyIfIdAlreadyExists() {
		final boolean exists = repository.studentExistsWithId(student.getId());

		if (exists) {
			throw new IllegalArgumentException(getIdRepeatedMessage(student.getId()));
		}
	}

	private static String getIdRepeatedMessage(final String idStudent) {
		return String.format("El id %s ya se encuentra registrado", idStudent);
	}

	private void tryToAddStudentToDb() {
		final boolean success = repository.insertStudent(student);

		if (!success) {
			throw new RuntimeException("Hubo un error al tratar de dar de alta al alumno");
		}
	}

	private String getSuccessMessage() {
		return String.format("Se inserto con exito el alumno con matricula %s", student.getId());
	}

	@Override
	public String toString() {
		return String.format(
				"CreateStudent (repository=%s, student=%s)",
				repository,
				student
		);
	}
}