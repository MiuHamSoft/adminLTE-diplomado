package mx.edu.utp.demospring.student.database;

import org.slf4j.Logger;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

import static java.lang.System.out;
import static org.slf4j.LoggerFactory.getLogger;

public class HttpClientExample {

	private static final Logger LOGGER = getLogger(HttpClientExample.class);

	public static void main(final String[] args) {
		final HttpClientExample clientExample = new HttpClientExample();
//		out.println(clientExample.getResponse());
		out.println(clientExample.postResponse());


	}

	public String getResponse() {
		final HttpClient httpClient = HttpClient.newBuilder()
				.version(HttpClient.Version.HTTP_1_1)
				.connectTimeout(Duration.ofSeconds(10))
				.build();

		final HttpRequest request = HttpRequest.newBuilder()
				.GET()
				.uri(URI.create("https://httpbin.org/get"))
				.setHeader("User-Agent", "Java 11 HttpClient")
				.build();

		final HttpResponse<String> response;

		try {
			response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
			return response.body();
		} catch (final IOException e) {
//			LOGGER.error("IO Exception", e);
			throw new UncheckedIOException(e);
		} catch (final InterruptedException e) {
			LOGGER.error("Interrupted Exception", e);
		}

		return "";
	}

	public String postResponse() {
		final String json = "{\"id\":\"ABC202002\",\"curp\":\"XEXX010101HNEXXXA6\",\"firstName\":\"asdfsqdtsfg\",\"lastName\":\"lastName\",\"yearOfBirth\":1995,\"gender\":\"HOMBRE\",\"group\":{\"semester\":1,\"letter\":\"A\",\"id\":1}}";
		final HttpClient httpClient = HttpClient.newBuilder()
				.version(HttpClient.Version.HTTP_1_1)
				.connectTimeout(Duration.ofSeconds(10))
				.build();

		final HttpRequest request = HttpRequest.newBuilder()
				.POST(HttpRequest.BodyPublishers.ofString(json))
				.uri(URI.create("https://httpbin.org/post"))
				.setHeader("User-Agent", "Java 11 HttpClient")
				.build();

		HttpResponse<String> response;

		try {
			response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
			return response.body();
		} catch (final IOException e) {
//			LOGGER.error("IO Exception", e);
			throw new UncheckedIOException(e);
		} catch (final InterruptedException e) {
			LOGGER.error("Interrupted Exception", e);
		}

		return "";
	}
}