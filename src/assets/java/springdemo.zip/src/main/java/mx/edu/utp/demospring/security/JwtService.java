package mx.edu.utp.demospring.security;

import mx.edu.utp.demospring.users.domain.User;
import org.springframework.security.core.Authentication;

public interface JwtService {
	String getToken(User user);
	Authentication getAuthorization(String token);
}