package mx.edu.utp.demospring.users.database;

import mx.edu.utp.demospring.users.domain.User;
import mx.edu.utp.demospring.users.domain.UserImpl;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public final class UsersMapper implements RowMapper<User> {

	private UsersMapper() {
	}

	public static RowMapper<User> create() {
		return new UsersMapper();
	}

	@Override
	public User mapRow(final ResultSet rs, final int rowNum) throws SQLException {
		final int id = rs.getInt("ID");
		final String username = rs.getString("USERNAME");
		final String firstName = rs.getString("FIRST_NAME");
		final String fathersLastName = rs.getString("FATHERS_LAST_NAME");
		final String mothersLastName = rs.getString("MOTHERS_LAST_NAME");
		final int idRole = rs.getInt("ID_ROLE");
		final String role = rs.getString("ROLE");

		return new UserImpl.Builder()
				.id(id)
				.username(username)
				.firstName(firstName)
				.fathersLastName(fathersLastName)
				.mothersLastName(mothersLastName)
				.idRole(idRole)
				.role(role)
				.build();
	}
}