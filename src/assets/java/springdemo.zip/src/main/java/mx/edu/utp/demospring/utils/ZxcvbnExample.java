package mx.edu.utp.demospring.utils;

import com.nulabinc.zxcvbn.Strength;
import com.nulabinc.zxcvbn.Zxcvbn;
import org.slf4j.Logger;

import static org.slf4j.LoggerFactory.getLogger;

public enum ZxcvbnExample {
	;

	private static final Logger LOGGER = getLogger(ZxcvbnExample.class);
	private static final String PASSWORD = "qwertyuiop";
	private static final int MIN_SCORE = 3;

	public static void main(final String[] args) {
		final Zxcvbn zxcvbn = new Zxcvbn();
		final Strength strength = zxcvbn.measure(PASSWORD);
		final int score = strength.getScore();

		if (score <= MIN_SCORE) {
			throw new IllegalArgumentException(getLowStrengthWarning(PASSWORD));
		}

		LOGGER.info("La fortaleza es de: {}", score);
	}

	private static String getLowStrengthWarning(final String password) {
		return String.format("La contraseña es muy debil: %s", password);
	}
}