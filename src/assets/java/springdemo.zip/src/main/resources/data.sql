CREATE SCHEMA curso;

CREATE TABLE curso.groups (
    id integer NOT NULL,
    letter character varying(1) NOT NULL,
    semester integer NOT NULL
);

CREATE SEQUENCE curso.group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE curso.group_id_seq OWNED BY curso.groups.id;

CREATE TABLE curso.students (
    serial integer NOT NULL,
    id character varying(20) NOT NULL,
    first_name character varying(40) NOT NULL,
    last_name character varying(40) NOT NULL,
    curp character varying(18) NOT NULL,
    gender character varying(1) NOT NULL,
    yearofbirth integer NOT NULL,
    id_group bigint NOT NULL
);

CREATE VIEW curso.students_groups_view AS
 SELECT students.id,
    students.serial,
    students.first_name,
    students.last_name,
    students.curp,
    students.gender,
    students.yearofbirth,
    students.id_group,
    groups.letter,
    groups.semester
   FROM (curso.students
     JOIN curso.groups ON ((students.id_group = groups.id)));

CREATE SEQUENCE curso.students_serial_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE curso.students_serial_seq OWNED BY curso.students.serial;

ALTER TABLE ONLY curso.groups ALTER COLUMN id SET DEFAULT nextval('curso.group_id_seq'::regclass);

ALTER TABLE ONLY curso.students ALTER COLUMN serial SET DEFAULT nextval('curso.students_serial_seq'::regclass);

INSERT INTO curso.groups VALUES (1, 'A', 1);

SELECT pg_catalog.setval('curso.group_id_seq', 1, false);

SELECT pg_catalog.setval('curso.students_serial_seq', 3, true);


ALTER TABLE ONLY curso.groups
    ADD CONSTRAINT groups_pk PRIMARY KEY (id);

ALTER TABLE ONLY curso.students
    ADD CONSTRAINT students_pk PRIMARY KEY (serial);

ALTER TABLE ONLY curso.students
    ADD CONSTRAINT students_un_curp UNIQUE (curp);


ALTER TABLE ONLY curso.students
    ADD CONSTRAINT students_un_id UNIQUE (id);

ALTER TABLE ONLY curso.students
    ADD CONSTRAINT students_fk FOREIGN KEY (id_group) REFERENCES curso.groups(id);