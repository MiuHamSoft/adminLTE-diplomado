--liquibase formatted sql

--changeset samuelPalma:opRhrs45
CREATE TABLE IF NOT EXISTS curso.new_table (
    id serial NOT NULL,
    "name" varchar(20) NOT NULL,
    CONSTRAINT new_table_pk PRIMARY KEY (id)
);
--changeset samuelPalma:B27uW5D9
ALTER TABLE curso."groups" ADD test varchar NULL;

--changeset samuelPalma:JNvo2Q4E
CREATE TABLE curso.roles (
	id serial NOT NULL,
	role varchar NOT NULL,
	CONSTRAINT role_pk PRIMARY KEY (id)
);

INSERT INTO curso.roles
(id, "role")
VALUES(1, 'ROLE_ADMIN');

INSERT INTO curso.roles
(id, "role")
VALUES(2, 'ROLE_TEACHER');

INSERT INTO curso.roles
(id, "role")
VALUES(3, 'ROLE_STUDENT');

--changeset samuelPalma:tJmCG75Y
CREATE TABLE curso.users (
	id serial NOT NULL,
	username varchar NOT NULL,
	hash varchar NOT NULL,
	first_name varchar NOT NULL,
	fathers_last_name varchar NOT NULL,
	mothers_last_name varchar NOT NULL,
	id_role int4 NOT NULL,
	active bool NOT NULL DEFAULT true,
	CONSTRAINT user_pk PRIMARY KEY (username)
);

ALTER TABLE curso.users ADD CONSTRAINT users_roles_fk FOREIGN KEY ("id_role") REFERENCES curso.roles(id);


--changeset samuelPalma:TLkpsQpz
CREATE OR REPLACE VIEW curso.users_roles_view AS
SELECT users.id,
       users.username,
       users.hash,
       users.first_name,
       users.fathers_last_name,
       users.mothers_last_name,
       users.active,
       users.id_role,
       roles.role
FROM curso.users
JOIN curso.roles ON users.id_role = roles.id;

--changeset samuelPalma:UD1VWnch
INSERT INTO curso.users
(id, username, hash, first_name, fathers_last_name, mothers_last_name, id_role, active)
VALUES(1, 'admin', '$2a$10$OMPEn96fbvtMH9HZIoQgtujn3csJEMXRHrlywPKu.qT95nHvWX5oG', 'admin', 'admin', 'admin', 1, true);

INSERT INTO curso.users
(id, username, hash, first_name, fathers_last_name, mothers_last_name, id_role, active)
VALUES(2, 'teacher', '$2a$10$OMPEn96fbvtMH9HZIoQgtujn3csJEMXRHrlywPKu.qT95nHvWX5oG', 'teacher', 'teacher', 'teacher', 2, true);

INSERT INTO curso.users
(id, username, hash, first_name, fathers_last_name, mothers_last_name, id_role, active)
VALUES(3, 'student', '$2a$10$OMPEn96fbvtMH9HZIoQgtujn3csJEMXRHrlywPKu.qT95nHvWX5oG', 'student', 'student', 'student', 3, true);

